
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const getAIAssistantAdvice = async (jobDescription: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a technical support expert for a Fiber Optic Interruption team. 
      Analyze the following job description and provide 3 quick technical bullet points of advice or risks to consider. 
      Keep it brief and professional in Thai language.
      Job: ${jobDescription}`,
      config: {
        maxOutputTokens: 200,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "ไม่สามารถติดต่อ AI ได้ในขณะนี้";
  }
};

export const generateJobSummary = async (assignments: any[]) => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: `Analyze these recent technical assignments and summarize the top 3 critical issues or trends.
            Assignments: ${JSON.stringify(assignments.slice(0, 10))}`,
            config: {
                maxOutputTokens: 300,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        summary: { type: Type.STRING },
                        trends: { type: Type.ARRAY, items: { type: Type.STRING } },
                        recommendations: { type: Type.ARRAY, items: { type: Type.STRING } }
                    },
                    required: ["summary", "trends", "recommendations"]
                }
            }
        });
        return JSON.parse(response.text || "{}");
    } catch (e) {
        return { summary: "Analysis failed." };
    }
};
